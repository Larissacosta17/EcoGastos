package InsertDAO;
import usuario.historico;
import conexao.conexao;
import java.sql.PreparedStatement;

public class HistoricoDAO {
    
    public void cadastrarHistorico(historico historico){

        String sql = "INSERT INTO historico (idusuario, resultado, discricao) VALUES (?, ?, ?)";

        PreparedStatement ps = null;
        try {
            ps = conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, historico.getIdusuario());
            ps.setDouble(2, historico.getResultado());
            ps.setString(3, historico.getDiscricao());
            
            ps.execute();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("historico não registrado");
        }
    }
}
