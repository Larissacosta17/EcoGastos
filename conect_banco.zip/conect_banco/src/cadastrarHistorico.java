import InsertDAO.HistoricoDAO;
import usuario.historico;

public class cadastrarHistorico {   
    public static void main(String[] args) throws Exception {
       
        historico h = new historico();
        h.setIdusuario(1);
        h.setResultado(200);
        h.setDiscricao("Adequado");

        new HistoricoDAO().cadastrarHistorico(h);
    }
}
