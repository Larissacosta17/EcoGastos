package SelectDAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexao.conexao;

public class selectHistoricoDAO {
    

     public static void exibirHistorico() {
        
        int idusuario = selectLoginDAO.getIdUsuariologado();
        
        String sql = "SELECT * FROM ecogastos.historico where idusuario = ?;";

        try (PreparedStatement pstmt = conexao.getConexao().prepareStatement(sql)) {
            pstmt.setInt(1, idusuario);
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("\n Segue abaixo o seu historico!:");
                do{
                    System.out.println("\n RESULTADO: " + rs.getString("resultado") + " DESCRIÇÃO DO RESULTADO " + rs.getString("discricao"));
                } while(rs.next());
            
            } else {
                System.out.println("\n você ainda não tem nem um historico faça um calculo para adicionalo ao historico");
            }
        } catch (SQLException e) {
            System.out.println("\n Erro ao ver o historico: " + e.getMessage());

        }
    }
}
