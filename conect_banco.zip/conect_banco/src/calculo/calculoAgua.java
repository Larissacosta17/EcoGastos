package calculo;

import java.util.Scanner;

import usuario.historico;
import InsertDAO.HistoricoDAO;
import SelectDAO.selectLoginDAO;

public class calculoAgua {

    public String CalcularAgua(){

        Scanner scanner = new Scanner(System.in);
       
        System.out.println("Informe quantas pessoas tem em sua residencia");
        int Pessoas =  scanner.nextInt();

        System.out.println("Informe o consumo  medio Consumo Diário (Litros) da sua residencia  Obs: essa informação pode ser obitida na sua conta de água");
        double ConsumoDiario = scanner.nextDouble();
        String Descricao = "";

        double LitrosPessoaDia;
        
        LitrosPessoaDia = Math.ceil(ConsumoDiario / Pessoas);


        if (Pessoas <= 0 || ConsumoDiario <= 0) {
              
            Descricao = "favor colocar um valor valido";
            return Descricao;
        }

        else{

            if (LitrosPessoaDia > 185) {
                Descricao = "Muito alto";
            } else if ((LitrosPessoaDia >= 156)  &&  (LitrosPessoaDia <= 185 )) {
                Descricao = "Alto";
            } else if ((LitrosPessoaDia >= 131)  &&  (LitrosPessoaDia <= 155 )) {
                Descricao = "Médio";
            } else if ((LitrosPessoaDia >= 111) &&  (LitrosPessoaDia <= 130 )) {		
                Descricao = "Adequado";
            } else if (LitrosPessoaDia <= 110) {
                Descricao = "Ótimo";
            }
        }

        
        historico h = new historico();
        h.setIdusuario(selectLoginDAO.getIdUsuariologado());
        h.setResultado(LitrosPessoaDia);
        h.setDiscricao(Descricao);
        new HistoricoDAO().cadastrarHistorico(h);
        return "Consumo médio por pessoa por dia: " + LitrosPessoaDia + " litros seu consumo é " + Descricao;

    }
}
