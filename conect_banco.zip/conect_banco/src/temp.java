import SelectDAO.selectLoginDAO;
import calculo.calculoAgua;

public class temp {
        public static void main(String[] args) throws Exception {

               System.out.println( new calculoAgua().CalcularAgua());
                

  
                        
        }
}
